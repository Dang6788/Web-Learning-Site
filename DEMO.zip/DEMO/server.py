# coding:utf-8

from flask import Flask, render_template, request, redirect
import fileutils

# 引入file_dict课程列表
fileutils.file_read()

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('login.html')


@app.route('/loginaction/', methods=["POST", "GET"])
def login():
    error_msg = ''

    if request.method == 'GET':
        username = request.args.get('username')
        password = request.args.get('password')
    else:
        username = request.form.get('username')
        password = request.form.get('password')

    print('username:%s,password:%s' % (username, password))

    if username and password:
        if username == "admin" and password == "admin":
            return redirect('/list')
        else:
            error_msg = "username or password is wrong"
    else:
        error_msg = 'need username and password'

    return render_template('login.html', error_msg=error_msg)


@app.route('/list/')
def courselist():
    courselist = fileutils.file_read().items()
    print('courselist:%s' % courselist)
    return render_template('list.html', courselist=courselist)


@app.route('/update/')
def update():
    cid = request.args.get('cid')
    cname = fileutils.file_read().get('cname')
    course = [cid,cname]
    print('update:%s' % course)
    return render_template('update.html', course = course)


@app.route('/updateaction/', methods=['POST'])
def updateaction():
    params = request.args if request.method == 'GET' else request.form

    cid = params.get('cid')
    cname = params.get('cname')
    fileutils.file_dict[cid] = cname
    fileutils.file_write()
    return redirect('/list/')


@app.route('/add/')
def add():
    return render_template('add.html')


@app.route('/addaction/', methods=['POST'])
def addaction():
    params = request.args if request.method == 'GET' else request.form
    cid = params.get('cid')
    cname = params.get('cname')

    if cid in fileutils.file_dict:
        return redirect('/list/')
    else:
        fileutils.file_dict[cid] = cname
        fileutils.file_write()
        return redirect('/list/')


@app.route('/delete/')
def delete():
    cid = request.args.get('cid')
    fileutils.file_dict.pop(cid)
    fileutils.file_write()
    return redirect('/list/')


if __name__ == "__main__":
    app.run(debug=True)